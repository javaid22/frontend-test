module.exports = {
    extends: ['airbnb', 'airbnb/hooks'],
    rules: {
        indent: ['error', 'tab'],
        'no-console': ['warn'],
        'func-names': ['warn', 'never'],
        'no-tabs': 0,
        'max-len': ['error', { code: 150 }],
    },
    globals: {
        lightGallery: 'writable',
        jQuery: true,
    },
    env: {
        browser: true,
    },
};
